const yesBtn = document.getElementById("yesBtn");
const noBtn = document.getElementById("noBtn");
const letter = document.querySelector(".letter");
const nextPage = document.querySelector(".next-page");

yesBtn.addEventListener("click", () => {
  letter.classList.add("hidden");
  nextPage.classList.remove("hidden");
});

noBtn.addEventListener("mouseover", () => {
  const x = Math.random() * (window.innerWidth - 100);
  const y = Math.random() * (window.innerHeight - 100);
  noBtn.style.position = "absolute";
  noBtn.style.left = `${x}px`;
  noBtn.style.top = `${y}px`;
});
